# DriftMiner

Drift Detection as Code - Define custom infrastructure drift detection rules across any platform.

## Overview

DriftMiner is a lightweight tool that enables you to define and detect infrastructure drift using code. While tools like Terraform Cloud and AWS Config provide drift detection, DriftMiner allows you to write custom drift rules that work across any platform or infrastructure.

## Features

- 🔍 Define drift detection rules using YAML
- 🚀 Run as a CLI tool (GitHub Action coming soon)
- 🌐 Support for multiple cloud providers and IaC tools
- ⚡ Fast, efficient scanning of infrastructure state
- 📝 Custom rule definitions for:
  - Resource tags
  - Instance configurations
  - Environment variables
  - Security settings
  - And more!

## Installation

### Using Homebrew

```bash
brew tap driftminer/driftminer
brew install driftminer
```

### From Source

1. Clone the repository:
```bash
git clone https://github.com/driftminer/driftminer.git
cd driftminer
```

2. Set up Python environment (requires Python 3.8+):
```bash
python -m venv venv
source venv/bin/activate
pip install -e .
```

3. Set PYTHONPATH to include the project source:
```bash
export PYTHONPATH=/path/to/driftminer/src:$PYTHONPATH
```

## Quick Start

1. Create a drift rules file (`drift-rules.yml`):

```yaml
rules:
  - id: ec2-instance-type
    resource_type: aws_ec2_instance
    filter:
      tags:
        Environment: production
    assert:
      instance_type: t3.medium

  - id: s3-tag-check
    resource_type: aws_s3_bucket
    assert:
      tags:
        Owner: present
```

2. Create a mock resources file for testing (`resources.json`):
```json
{
  "resources": [
    {
      "id": "i-1234567890abcdef0",
      "resource_type": "aws_ec2_instance",
      "instance_type": "t2.micro",
      "tags": {
        "Environment": "production",
        "Owner": "team-a"
      }
    }
  ]
}
```

3. Run DriftMiner:
```bash
# Make sure your virtual environment is activated and PYTHONPATH is set
python -c "from driftminer.cli import main; main()" scan --rules drift-rules.yml --input resources.json
```

Or you can use this one-liner that sets up everything:
```bash
source venv/bin/activate && PYTHONPATH=/path/to/driftminer/src python -c "from driftminer.cli import main; main()" scan --rules drift-rules.yml --input resources.json
```

## Rule Format

DriftMiner rules are defined in YAML with the following structure:

- `id`: Unique identifier for the rule
- `resource_type`: Type of cloud resource to check
- `filter` (optional): Conditions to select specific resources
  - `tags`: Key-value pairs for tag-based filtering
- `assert`: Required conditions that must be true
  - Can specify exact values: `instance_type: t3.medium`

## Contributing

Thank you for your interest in contributing to DriftMiner!

### Project Structure

```
driftminer/
├── src/
│   └── driftminer/     # Python package
│       ├── cli.py      # Command-line interface
│       ├── rules.py    # Rule parsing and validation
│       ├── scanner.py  # Resource scanning logic
│       └── reporter.py # Results reporting
└── tests/             # Test files
```

### Development Roadmap

#### Phase 1 (Current)
We are currently in Phase 1 (MVP) with the following components:
- ✅ Command-line parser
- ✅ Rules file parser
- ✅ Mock resource loader (JSON)
- ✅ Simple assertion engine
- ✅ Basic reporting

#### Planned Features
1. Cloud Provider Integration
   - AWS resource scanning
   - Azure resource scanning
   - GCP resource scanning

2. IaC Integration
   - Terraform state parsing
   - CloudFormation template parsing
   - Pulumi state parsing

3. Enhanced Rule Features
   - Regular expression matching
   - Numerical comparisons (>, <, >=, <=)
   - Complex logical conditions (AND, OR, NOT)
   - Custom validation functions

### Pull Request Process

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Make your changes
4. Add tests for your changes
5. Run tests locally
6. Update documentation if needed
7. Commit your changes (`git commit -m 'Add amazing feature'`)
8. Push to your fork (`git push origin feature/amazing-feature`)
9. Create a Pull Request

### Coding Standards

#### Python
- Follow PEP 8 style guide
- Use type hints
- Add docstrings for all functions and classes
- Maintain test coverage

#### Go
- Follow standard Go formatting (`go fmt`)
- Add comments for exported functions
- Follow idiomatic Go practices

### Running Tests
```bash
# Python tests
pytest tests/

# Go tests
go test ./...
```
  - Can check for presence: `Owner: present`

## Contributing

Contributions are welcome! The project is currently in MVP phase with the following components:

- ✅ Command-line parser
- ✅ Rules file parser
- ✅ Mock resource loader (JSON)
- ✅ Simple assertion engine
- ✅ Basic reporting (stdout + exit code)

Please see our [Contributing Guide](CONTRIBUTING.md) for details on how to get started.

## License

MIT