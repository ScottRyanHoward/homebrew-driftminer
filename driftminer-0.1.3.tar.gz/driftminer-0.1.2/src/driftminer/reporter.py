"""Results reporting."""
from typing import List
from rich.console import Console
from rich.table import Table
from .scanner import DriftResult

console = Console()

def report_results(results: List[DriftResult]) -> int:
    """Report drift detection results and return exit code."""
    if not results:
        console.print("[green]No drift detected![/green]")
        return 0
        
    table = Table(title="Drift Detection Results")
    table.add_column("Rule ID", style="cyan")
    table.add_column("Resource Type", style="blue")
    table.add_column("Resource ID", style="yellow")
    table.add_column("Status", style="green")
    table.add_column("Message", style="white")
    
    for result in results:
        status_style = "green" if result.passed else "red"
        message_style = "green" if result.passed else "red"
        
        table.add_row(
            result.rule.id,
            result.resource.get('resource_type', ''),
            result.resource.get('id', ''),
            f"[{status_style}]{'✅ PASSED' if result.passed else '❌ FAILED'}[/{status_style}]",
            f"[{message_style}]{result.message}[/{message_style}]"
        )
    
    # Print table and summary
    console.print(table)
    passed = sum(1 for r in results if r.passed)
    total = len(results)
    console.print(f"\nSummary: [green]{passed}[/green]/[white]{total}[/white] checks passed")
    
    return 1 if any(not r.passed for r in results) else 0
