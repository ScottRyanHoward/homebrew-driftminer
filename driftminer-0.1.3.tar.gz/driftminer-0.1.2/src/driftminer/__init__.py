"""DriftMiner - Drift Detection as Code."""

__version__ = "0.1.0"
