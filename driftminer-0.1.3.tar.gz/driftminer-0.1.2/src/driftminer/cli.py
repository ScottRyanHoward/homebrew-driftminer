"""DriftMiner CLI interface."""
import click
from rich.console import Console

from . import __version__
from .rules import load_rules
from .scanner import scan_resources
from .reporter import report_results

console = Console()

@click.group()
@click.version_option(version="0.1.0")
def main():
    """DriftMiner - Drift Detection as Code"""
    pass

@main.command()
@click.option('--rules', '-r', 'rules_file', required=True, type=click.Path(exists=True), help='Path to rules YAML file')
@click.option('--input', '-i', help='Path to mock resource JSON file (for testing)')
def scan(rules_file, input):
    """Scan infrastructure for drift using rules from RULES_FILE."""
    try:
        rules = load_rules(rules_file)
        results = scan_resources(rules, mock_input=input)
        exit_code = report_results(results)
        raise SystemExit(exit_code)
    except Exception as e:
        console.print(f"[red]Error:[/red] {str(e)}")
        raise SystemExit(1)

if __name__ == '__main__':
    main()
