"""Resource scanning and drift detection."""
import json
from typing import Dict, List, Any
from .rules import Rule

class DriftResult:
    def __init__(self, rule: Rule, resource: Dict[str, Any], passed: bool, message: str):
        self.rule = rule
        self.resource = resource
        self.passed = passed
        self.message = message

def scan_resources(rules: List[Rule], mock_input: str = None) -> List[DriftResult]:
    """Scan resources for drift against rules."""
    results = []
    
    # For MVP, we'll use mock resources from a JSON file
    if mock_input:
        with open(mock_input) as f:
            data = json.load(f)
            resources = data.get('resources', [])
    else:
        # TODO: Implement actual cloud provider scanning
        resources = []
    
    for resource in resources:
        for rule in rules:
            if resource.get('resource_type') != rule.resource_type:
                continue
                
            if not rule.matches_resource(resource):
                continue
            
            # Track if all assertions pass for this rule
            all_passed = True
            failure_message = ""
            
            # Check assertions
            for key, expected in rule.assert_conditions.items():
                if key == 'tags':
                    for tag_key, tag_value in expected.items():
                        actual = resource.get('tags', {}).get(tag_key)
                        if tag_value == 'present':
                            if actual is None:
                                all_passed = False
                                failure_message = f"Required tag '{tag_key}' is missing"
                                break
                        elif actual != tag_value:
                            all_passed = False
                            failure_message = f"Tag '{tag_key}' has value '{actual}' but expected '{tag_value}'"
                            break
                else:
                    actual = resource.get(key)
                    if actual != expected:
                        all_passed = False
                        failure_message = f"Property '{key}' has value '{actual}' but expected '{expected}'"
                        break
            
            # Add result whether it passed or failed
            results.append(DriftResult(
                rule, resource, all_passed,
                "All checks passed" if all_passed else failure_message
            ))
    
    return results
