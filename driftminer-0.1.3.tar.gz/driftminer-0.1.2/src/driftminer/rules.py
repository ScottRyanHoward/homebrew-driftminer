"""Rule parsing and validation."""
import yaml
from typing import Dict, List, Any

class Rule:
    def __init__(self, rule_dict: Dict[str, Any]):
        self.id = rule_dict['id']
        self.resource_type = rule_dict['resource_type']
        self.filter = rule_dict.get('filter', {})
        self.assert_conditions = rule_dict['assert']

    def matches_resource(self, resource: Dict[str, Any]) -> bool:
        """Check if a resource matches this rule's filters."""
        if not self.filter:
            return True
            
        # Check tag filters
        if 'tags' in self.filter:
            resource_tags = resource.get('tags', {})
            for key, value in self.filter['tags'].items():
                if resource_tags.get(key) != value:
                    return False
        return True

def load_rules(rules_file: str) -> List[Rule]:
    """Load and validate rules from a YAML file."""
    with open(rules_file) as f:
        data = yaml.safe_load(f)
    
    if not isinstance(data, dict) or 'rules' not in data:
        raise ValueError("Invalid rules file format: must contain a 'rules' list")
    
    rules = []
    for rule_dict in data['rules']:
        if not isinstance(rule_dict, dict):
            raise ValueError("Each rule must be a dictionary")
        if 'id' not in rule_dict:
            raise ValueError("Each rule must have an 'id'")
        if 'resource_type' not in rule_dict:
            raise ValueError("Each rule must have a 'resource_type'")
        if 'assert' not in rule_dict:
            raise ValueError("Each rule must have 'assert' conditions")
            
        rules.append(Rule(rule_dict))
    
    return rules
