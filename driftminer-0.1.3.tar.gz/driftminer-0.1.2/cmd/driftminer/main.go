package main

import (
	"fmt"
	"os"
	"os/exec"
)

const version = "0.1.0"

func main() {
	// For MVP, the Go binary is just a wrapper around the Python implementation
	// This allows us to distribute via Homebrew while keeping the core logic in Python
	pythonCmd := exec.Command("python", "-m", "driftminer")
	pythonCmd.Args = append(pythonCmd.Args, os.Args[1:]...)
	pythonCmd.Stdout = os.Stdout
	pythonCmd.Stderr = os.Stderr

	if err := pythonCmd.Run(); err != nil {
		if exitErr, ok := err.(*exec.ExitError); ok {
			os.Exit(exitErr.ExitCode())
		}
		fmt.Fprintf(os.Stderr, "Error running driftminer: %v\n", err)
		os.Exit(1)
	}
}
